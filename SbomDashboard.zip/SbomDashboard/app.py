"""SBOM Fixer Dashboard: a small local web server (Python standard library only).

    python app.py                 start on http://127.0.0.1:8765 and open the browser
    python app.py --port 9000     other port
    python app.py --no-browser    do not open the browser
    python app.py --host 0.0.0.0  let other machines on the network open it (default: this machine only)

The page, its scripts and fonts are all in the web/ folder; nothing is loaded from the internet.
"""

from __future__ import annotations

import argparse
import io
import json
import mimetypes
import re
import secrets
import socket
import sys
import threading
import time
import webbrowser
import zipfile
from collections import OrderedDict
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
LIBS = ROOT / "libs" / f"py{sys.version_info.major}{sys.version_info.minor}"
sys.path.insert(0, str(ROOT))


def ensure_dependencies() -> None:
    """Install the libraries from wheelhouse/ on the first run (no internet needed), into libs/pyXY."""
    sys.path.insert(0, str(LIBS))
    try:
        import fastjsonschema, jsonschema, packageurl, referencing, yaml  # noqa: F401, E401
        import jsonpatch, license_expression  # noqa: F401, E401
        return
    except ImportError:
        pass
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or newer is needed (this is Python "
                         f"{sys.version_info.major}.{sys.version_info.minor}).")
    print("First start: installing the libraries from the wheelhouse folder (no internet needed)...")
    import subprocess

    cmd = [sys.executable, "-m", "pip", "install", "--no-index", "--find-links", str(ROOT / "wheelhouse"),
           "--target", str(LIBS), "--upgrade", "--no-warn-script-location", "-q", "-r", str(ROOT / "requirements.txt")]
    if subprocess.run(cmd).returncode != 0:
        raise SystemExit("Could not install the libraries from wheelhouse/. Is pip available? "
                         "Try:  python -m ensurepip   and start again.")
    import importlib

    importlib.invalidate_caches()


ensure_dependencies()
import analyzer  # noqa: E402

WEB = ROOT / "web"
SAMPLES = ROOT / "samples"
MAX_UPLOAD = 256 * 1024 * 1024
MAX_KEPT = 12  # results kept in memory for the download links

_results: OrderedDict[str, dict] = OrderedDict()
_lock = threading.Lock()


def _keep(result: dict) -> str:
    rid = secrets.token_hex(8)
    with _lock:
        _results[rid] = result
        while len(_results) > MAX_KEPT:
            _results.popitem(last=False)
    return rid


def _report_json(result: dict) -> bytes:
    slim = {k: v for k, v in result.items() if k not in ("files", "graph")}
    return json.dumps(slim, indent=2, ensure_ascii=False).encode("utf-8")


def _zip_bytes(result: dict) -> bytes:
    f = result["files"]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        if f.get("sbom"):
            z.writestr(f["sbom_name"], f["sbom"])
        z.writestr(f"{f['stem']}.tech-notes.txt", f["tech_notes"])
        z.writestr(f"{f['stem']}.suggestions.txt", f["suggestions"])
        z.writestr(f"{f['stem']}.report.json", _report_json(result))
    return buf.getvalue()


class Handler(BaseHTTPRequestHandler):
    server_version = "SbomDashboard/1.0"

    def log_message(self, fmt: str, *args) -> None:  # quiet console
        if "--verbose" in sys.argv:
            super().log_message(fmt, *args)

    # ------------------------------------------------------------ helpers
    def _send(self, status: int, body: bytes, ctype: str, extra: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, payload: object) -> None:
        self._send(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _error(self, status: int, message: str) -> None:
        self._json(status, {"ok": False, "error": message})

    def _analyze(self, raw: bytes, name: str, ecosystem: str | None) -> None:
        try:
            result = analyzer.analyze(raw, name, ecosystem or None)
        except Exception as exc:  # the dashboard must never crash on a strange file
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, f"Unexpected error while fixing the file: {exc}")
            return
        result["id"] = _keep(result) if result.get("ok") or result.get("files") else None
        self._json(HTTPStatus.OK, result)

    # ------------------------------------------------------------ routes
    def do_GET(self) -> None:  # noqa: N802
        url = urlparse(self.path)
        path = unquote(url.path)
        query = parse_qs(url.query)
        if path == "/api/info":
            samples = sorted(p.name for p in SAMPLES.glob("*.json")) if SAMPLES.is_dir() else []
            return self._json(HTTPStatus.OK, {"engine": analyzer.ENGINE_VERSION, "ecosystems": analyzer.ecosystems(),
                                              "samples": samples})
        m = re.fullmatch(r"/api/sample/([\w.\-]+)", path)
        if m:
            sample = SAMPLES / m.group(1)
            if not sample.is_file() or sample.parent != SAMPLES:
                return self._error(HTTPStatus.NOT_FOUND, "Sample not found.")
            return self._analyze(sample.read_bytes(), sample.name, (query.get("ecosystem") or [None])[0])
        m = re.fullmatch(r"/download/([0-9a-f]{16})/(sbom|notes|suggestions|report|zip)", path)
        if m:
            return self._download(m.group(1), m.group(2))
        return self._static(path)

    def do_POST(self) -> None:  # noqa: N802
        url = urlparse(self.path)
        if url.path != "/api/fix":
            return self._error(HTTPStatus.NOT_FOUND, "Unknown address.")
        query = parse_qs(url.query)
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0:
            return self._error(HTTPStatus.BAD_REQUEST, "No file was received.")
        if length > MAX_UPLOAD:
            return self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "The file is larger than 256 MB.")
        raw = self.rfile.read(length)
        name = Path((query.get("name") or ["sbom.json"])[0]).name or "sbom.json"
        self._analyze(raw, name, (query.get("ecosystem") or [None])[0])

    def _download(self, rid: str, kind: str) -> None:
        with _lock:
            result = _results.get(rid)
        if result is None:
            return self._error(HTTPStatus.NOT_FOUND, "This result is no longer available. Fix the file again.")
        f = result["files"]
        stem = f["stem"]
        table = {
            "sbom": (lambda: (f["sbom"] or "").encode("utf-8"), f["sbom_name"], "application/json"),
            "notes": (lambda: f["tech_notes"].encode("utf-8"), f"{stem}.tech-notes.txt", "text/plain; charset=utf-8"),
            "suggestions": (lambda: f["suggestions"].encode("utf-8"), f"{stem}.suggestions.txt",
                            "text/plain; charset=utf-8"),
            "report": (lambda: _report_json(result), f"{stem}.report.json", "application/json"),
            "zip": (lambda: _zip_bytes(result), f"{stem}.sbom-fixer.zip", "application/zip"),
        }
        make, filename, ctype = table[kind]
        body = make()
        if not body:
            return self._error(HTTPStatus.NOT_FOUND, "This file was not produced.")
        self._send(HTTPStatus.OK, body, ctype, {"Content-Disposition": f'attachment; filename="{filename}"'})

    def _static(self, path: str) -> None:
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        target = (WEB / rel).resolve()
        if WEB not in target.parents or not target.is_file():
            return self._error(HTTPStatus.NOT_FOUND, "Not found.")
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        self._send(HTTPStatus.OK, target.read_bytes(), ctype)


def _free_port(host: str, wanted: int) -> int:
    for port in range(wanted, wanted + 60):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise SystemExit(f"No free port found between {wanted} and {wanted + 59}.")


def main() -> None:
    ap = argparse.ArgumentParser(description="SBOM Fixer Dashboard (offline)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    port = _free_port(args.host, args.port)
    server = ThreadingHTTPServer((args.host, port), Handler)
    url = f"http://{'127.0.0.1' if args.host in ('0.0.0.0', '') else args.host}:{port}/"
    print(f"SBOM Fixer Dashboard {analyzer.ENGINE_VERSION} is running at {url}")
    print("Keep this window open while you use it. Press Ctrl+C to stop.")
    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
        time.sleep(0.1)


if __name__ == "__main__":
    main()
