"""Fill wheelhouse/ with every dependency wheel, for Windows, Linux and macOS and Python 3.11 to 3.14.

Run this ONCE on a machine that has internet, then copy the whole folder anywhere. The machine that runs the
dashboard needs no internet: start.bat / start.sh install from wheelhouse/ with `pip --no-index`.

    python tools/build_wheelhouse.py
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WHEELS = ROOT / "wheelhouse"
PYTHONS = ["3.11", "3.12", "3.13", "3.14"]
# pip platform tags that cover most machines
PLATFORMS = [
    ["win_amd64"],
    ["manylinux2014_x86_64", "manylinux_2_17_x86_64", "manylinux_2_28_x86_64"],
    ["manylinux2014_aarch64", "manylinux_2_17_aarch64", "manylinux_2_28_aarch64"],
    ["macosx_11_0_arm64", "macosx_10_13_universal2"],
    ["macosx_10_13_x86_64", "macosx_10_9_x86_64"],
]


def download(py: str, platform: list[str]) -> bool:
    cmd = [sys.executable, "-m", "pip", "download", "-r", str(ROOT / "requirements.txt"), "-d", str(WHEELS),
           "--only-binary=:all:", "--python-version", py, "--no-input", "-q"]
    for tag in platform:
        cmd += ["--platform", tag]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  FAILED {py} {platform[0]}: {result.stderr.strip().splitlines()[-1] if result.stderr.strip() else ''}")
    return result.returncode == 0


def main() -> int:
    WHEELS.mkdir(exist_ok=True)
    failed = 0
    for py in PYTHONS:
        for platform in PLATFORMS:
            print(f"Python {py} / {platform[0]} ...")
            failed += not download(py, platform)
    files = sorted(p.name for p in WHEELS.glob("*.whl"))
    print(f"\n{len(files)} wheels in {WHEELS} ({sum(p.stat().st_size for p in WHEELS.glob('*.whl')) / 1e6:.1f} MB)")
    return 1 if failed == len(PYTHONS) * len(PLATFORMS) else 0


if __name__ == "__main__":
    raise SystemExit(main())
