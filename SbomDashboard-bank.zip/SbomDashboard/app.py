"""SBOM Fixer Dashboard: a small local web server (Python standard library only).

    python app.py                 start on http://127.0.0.1:8765 and open the browser
    python app.py --port 9000     other port
    python app.py --no-browser    do not open the browser
    python app.py --host 0.0.0.0  let other machines on the network open it (default: this machine only)

The page, its scripts and fonts are all in the web/ folder; nothing is loaded from the internet.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import mimetypes
import re
import secrets
import socket
import sys
import threading
import time
import webbrowser
import zipfile
from collections import OrderedDict
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
LIBS = ROOT / "libs" / f"py{sys.version_info.major}{sys.version_info.minor}"
# vendor/ holds every library as plain .py files (no compiled .pyd/.so), so it works on locked-down machines
# where security software blocks compiled extensions, and on any OS / Python 3.11+ without pip.
VENDOR = ROOT / "vendor"
sys.path.insert(0, str(ROOT))


def ensure_dependencies() -> None:
    """Install the libraries from wheelhouse/ on the first run (no internet needed), into libs/pyXY."""
    if VENDOR.is_dir():
        sys.path.insert(0, str(VENDOR))
        try:
            import fastjsonschema, jsonschema, packageurl, referencing, yaml  # noqa: F401, E401
            import jsonpatch, license_expression  # noqa: F401, E401
            return
        except ImportError as exc:
            print(f"vendor/ libraries could not be used ({exc}); trying the wheelhouse instead...")
            sys.path.remove(str(VENDOR))
    sys.path.insert(0, str(LIBS))
    try:
        import fastjsonschema, jsonschema, packageurl, referencing, yaml  # noqa: F401, E401
        import jsonpatch, license_expression  # noqa: F401, E401
        return
    except ImportError:
        pass
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or newer is needed (this is Python "
                         f"{sys.version_info.major}.{sys.version_info.minor}).")
    print("First start: installing the libraries from the wheelhouse folder (no internet needed)...")
    import subprocess

    cmd = [sys.executable, "-m", "pip", "install", "--no-index", "--find-links", str(ROOT / "wheelhouse"),
           "--target", str(LIBS), "--upgrade", "--no-warn-script-location", "-q", "-r", str(ROOT / "requirements.txt")]
    if subprocess.run(cmd).returncode != 0:
        raise SystemExit("Could not install the libraries from wheelhouse/. Is pip available? "
                         "Try:  python -m ensurepip   and start again.")
    import importlib

    importlib.invalidate_caches()


ensure_dependencies()
import analyzer  # noqa: E402

WEB = ROOT / "web"
SAMPLES = ROOT / "samples"
MAX_UPLOAD = 256 * 1024 * 1024
MAX_KEPT = 300                       # results kept in memory for the download links
MAX_KEPT_BYTES = 900 * 1024 * 1024   # ... and their files together (the oldest go first)
MAX_BATCHES = 20
MAX_ZIP_ENTRIES = 1000
MAX_ZIP_TOTAL = 1024 * 1024 * 1024   # uncompressed size of the SBOMs read from one zip
SBOM_EXT = (".json", ".cdx", ".spdx", ".bom", ".sbom")
_ID = re.compile(r"[0-9a-f]{16}")

_results: OrderedDict[str, dict] = OrderedDict()
_sizes: dict[str, int] = {}
_batches: OrderedDict[str, list[dict]] = OrderedDict()   # batch id -> one item per SBOM, in upload order
_pending: OrderedDict[str, dict] = OrderedDict()         # batch id -> SBOMs read from zips, not fixed yet
_lock = threading.Lock()


def _size_of(result: dict) -> int:
    return sum(len(v) for v in (result.get("files") or {}).values() if isinstance(v, str))


def _keep(result: dict) -> str:
    rid = secrets.token_hex(8)
    with _lock:
        _results[rid] = result
        _sizes[rid] = _size_of(result)
        while len(_results) > 1 and (len(_results) > MAX_KEPT or sum(_sizes.values()) > MAX_KEPT_BYTES):
            old, _ = _results.popitem(last=False)
            _sizes.pop(old, None)
    return rid


def _register(bid: str, item: dict) -> None:
    with _lock:
        _batches.setdefault(bid, []).append(item)
        while len(_batches) > MAX_BATCHES:
            _batches.popitem(last=False)


def _report_json(result: dict) -> bytes:
    slim = {k: v for k, v in result.items() if k not in ("files", "graph")}
    return json.dumps(slim, indent=2, ensure_ascii=False).encode("utf-8")


def _zip_bytes(result: dict) -> bytes:
    f = result["files"]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        if f.get("sbom"):
            z.writestr(f["sbom_name"], f["sbom"])
        z.writestr(f"{f['stem']}.tech-notes.txt", f["tech_notes"])
        z.writestr(f"{f['stem']}.suggestions.txt", f["suggestions"])
        z.writestr(f"{f['stem']}.report.json", _report_json(result))
    return buf.getvalue()


def _safe(name: str) -> str:
    return re.sub(r"[^\w.\- ]", "_", name).strip(" .") or "sbom"


def _batch_zip(bid: str) -> bytes | None:
    """One folder per SBOM (fixed SBOM, tech notes, what to fix, report) plus batch-summary.csv."""
    with _lock:
        items = list(_batches.get(bid) or [])
    if not items:
        return None
    buf = io.BytesIO()
    used: set[str] = set()
    rows = [["file", "result", "spec", "version", "generator", "components_in", "components_out", "mistakes", "repairs",
             "layout_changes", "checkmarx_scannable_pct", "readiness_before", "readiness_after", "folder", "note"]]
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for item in items:
            sm = item["summary"]
            with _lock:
                result = _results.get(item["id"]) if item.get("id") else None
            base = _safe(((result or {}).get("files") or {}).get("stem") or Path(item["name"]).stem)
            folder, n = base, 1
            while folder.lower() in used:
                n += 1
                folder = f"{base}-{n}"
            used.add(folder.lower())
            note = ""
            if result is not None and result.get("files"):
                f = result["files"]
                if f.get("sbom"):
                    z.writestr(f"{folder}/{f['sbom_name']}", f["sbom"])
                z.writestr(f"{folder}/{f['stem']}.tech-notes.txt", f["tech_notes"])
                z.writestr(f"{folder}/{f['stem']}.suggestions.txt", f["suggestions"])
                z.writestr(f"{folder}/{f['stem']}.report.json", _report_json(result))
            else:
                note = sm.get("error") or "Result is no longer in memory; fix this file again."
                z.writestr(f"{folder}/NOT-FIXED.txt", f"{item['name']}\n\n{note}\n")
            status = ("failed" if not sm.get("ok") else "clean" if sm.get("exit_code") == 0
                      else "fixed" if sm.get("exit_code") == 1 else f"warning: {sm.get('exit_text')}")
            rows.append([item["name"], status, sm.get("spec") or "", sm.get("version") or "", sm.get("generator") or "",
                         sm.get("components_in") or 0, sm.get("components_out") or 0, sm.get("problems") or 0,
                         sm.get("fixes") or 0, sm.get("layout") or 0, sm.get("scannable") if sm.get("scannable") is not None else "",
                         sm.get("readiness_before") if sm.get("readiness_before") is not None else "",
                         sm.get("readiness_after") if sm.get("readiness_after") is not None else "", folder, note])
        out = io.StringIO()
        csv.writer(out).writerows(rows)
        z.writestr("batch-summary.csv", "\ufeff" + out.getvalue())  # BOM: Excel reads it as UTF-8
    return buf.getvalue()


def _read_zip(bid: str, raw: bytes) -> tuple[list[dict], list[dict]]:
    """SBOM files inside a zip -> [{i, name, size}] (kept in memory for the fix calls) and what was skipped and why."""
    entries: list[dict] = []
    skipped: list[dict] = []
    zf = zipfile.ZipFile(io.BytesIO(raw))
    with _lock:
        slot = _pending.setdefault(bid, {"members": [], "names": set()})
        while len(_pending) > MAX_BATCHES:
            _pending.popitem(last=False)
    total = 0
    for info in zf.infolist():
        if info.is_dir():
            continue
        parts = PurePosixPath(info.filename.replace("\\", "/")).parts
        base = parts[-1] if parts else ""
        if not base or parts[0] == "__MACOSX" or base.startswith("._"):
            continue
        if not base.lower().endswith(SBOM_EXT):
            skipped.append({"name": info.filename, "reason": "not an SBOM file (.json, .cdx, .spdx expected)"})
            continue
        if info.flag_bits & 0x1:
            skipped.append({"name": info.filename, "reason": "password protected"})
            continue
        if info.file_size > MAX_UPLOAD:
            skipped.append({"name": info.filename, "reason": "larger than 256 MB"})
            continue
        if len(entries) >= MAX_ZIP_ENTRIES or total + info.file_size > MAX_ZIP_TOTAL:
            skipped.append({"name": info.filename, "reason": "zip holds too many / too large files; the rest were left out"})
            break
        total += info.file_size
        name = base
        if name.lower() in slot["names"] and len(parts) > 1:
            name = "__".join(parts[-2:])
        stem, n = name, 1
        while name.lower() in slot["names"]:
            n += 1
            name = f"{Path(stem).stem}-{n}{Path(stem).suffix}"
        slot["names"].add(name.lower())
        data = zf.read(info)
        with _lock:
            slot["members"].append((name, data))
            index = len(slot["members"]) - 1
        entries.append({"i": index, "name": name, "size": len(data)})
    return entries, skipped


class Handler(BaseHTTPRequestHandler):
    server_version = "SbomDashboard/1.0"

    def log_message(self, fmt: str, *args) -> None:  # quiet console
        if "--verbose" in sys.argv:
            super().log_message(fmt, *args)

    # ------------------------------------------------------------ helpers
    def _send(self, status: int, body: bytes, ctype: str, extra: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, payload: object) -> None:
        self._send(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _error(self, status: int, message: str) -> None:
        self._json(status, {"ok": False, "error": message})

    def _analyze(self, raw: bytes, name: str, ecosystem: str | None, bid: str | None = None, slim: bool = False) -> None:
        try:
            result = analyzer.analyze(raw, name, ecosystem or None)
        except Exception as exc:  # the dashboard must never crash on a strange file
            message = f"Unexpected error while fixing the file: {exc}"
            if bid:
                _register(bid, {"name": name, "id": None, "summary": {"name": name, "ok": False, "error": message}})
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, message)
            return
        result["id"] = _keep(result) if result.get("ok") or result.get("files") else None
        summary = analyzer.summarize(result)
        if bid:
            _register(bid, {"name": name, "id": result["id"], "summary": summary})
        self._json(HTTPStatus.OK, summary if slim else result)

    # ------------------------------------------------------------ routes
    def do_GET(self) -> None:  # noqa: N802
        url = urlparse(self.path)
        path = unquote(url.path)
        query = parse_qs(url.query)
        if path == "/api/info":
            samples = sorted(p.name for p in SAMPLES.glob("*.json")) if SAMPLES.is_dir() else []
            return self._json(HTTPStatus.OK, {"engine": analyzer.ENGINE_VERSION, "ecosystems": analyzer.ecosystems(),
                                              "samples": samples})
        m = re.fullmatch(r"/api/sample/([\w.\-]+)", path)
        if m:
            sample = SAMPLES / m.group(1)
            if not sample.is_file() or sample.parent != SAMPLES:
                return self._error(HTTPStatus.NOT_FOUND, "Sample not found.")
            return self._analyze(sample.read_bytes(), sample.name, (query.get("ecosystem") or [None])[0])
        m = re.fullmatch(r"/api/result/([0-9a-f]{16})", path)
        if m:
            with _lock:
                result = _results.get(m.group(1))
            if result is None:
                return self._error(HTTPStatus.NOT_FOUND, "This result is no longer available. Fix the file again.")
            return self._json(HTTPStatus.OK, result)
        m = re.fullmatch(r"/download/batch/([0-9a-f]{16})", path)
        if m:
            body = _batch_zip(m.group(1))
            if not body:
                return self._error(HTTPStatus.NOT_FOUND, "This batch is no longer available. Upload the files again.")
            return self._send(HTTPStatus.OK, body, "application/zip",
                              {"Content-Disposition": f'attachment; filename="sbom-fixer-batch-{m.group(1)[:6]}.zip"'})
        m = re.fullmatch(r"/download/([0-9a-f]{16})/(sbom|notes|suggestions|report|zip)", path)
        if m:
            return self._download(m.group(1), m.group(2))
        return self._static(path)

    def _body(self) -> bytes | None:
        """The request body, or None after an error answer."""
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0:
            self._error(HTTPStatus.BAD_REQUEST, "No file was received.")
            return None
        if length > MAX_UPLOAD:
            self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "The file is larger than 256 MB.")
            return None
        return self.rfile.read(length)

    def do_POST(self) -> None:  # noqa: N802
        url = urlparse(self.path)
        if url.path not in ("/api/fix", "/api/zip"):
            return self._error(HTTPStatus.NOT_FOUND, "Unknown address.")
        query = parse_qs(url.query)
        bid = (query.get("batch") or [""])[0]
        bid = bid if _ID.fullmatch(bid) else None
        if url.path == "/api/zip":
            if not bid:
                return self._error(HTTPStatus.BAD_REQUEST, "Missing batch id.")
            raw = self._body()
            if raw is None:
                return
            try:
                entries, skipped = _read_zip(bid, raw)
            except zipfile.BadZipFile:
                return self._error(HTTPStatus.BAD_REQUEST, "This is not a valid zip file.")
            return self._json(HTTPStatus.OK, {"ok": True, "batch": bid, "entries": entries, "skipped": skipped})
        name = Path((query.get("name") or ["sbom.json"])[0]).name or "sbom.json"
        eco = (query.get("ecosystem") or [None])[0]
        slim = (query.get("slim") or [""])[0] == "1"
        member = (query.get("member") or [""])[0]
        if member:  # an SBOM taken out of an uploaded zip earlier
            raw = None
            with _lock:
                members = (_pending.get(bid or "") or {}).get("members") or []
                if member.isdigit() and int(member) < len(members) and members[int(member)] is not None:
                    name, raw = members[int(member)]
                    members[int(member)] = None  # free the memory once it is being fixed
            if raw is None:
                return self._error(HTTPStatus.NOT_FOUND, "That file from the zip is no longer available.")
        else:
            raw = self._body()
            if raw is None:
                return
        self._analyze(raw, name, eco, bid, slim)

    def _download(self, rid: str, kind: str) -> None:
        with _lock:
            result = _results.get(rid)
        if result is None:
            return self._error(HTTPStatus.NOT_FOUND, "This result is no longer available. Fix the file again.")
        f = result["files"]
        stem = f["stem"]
        table = {
            "sbom": (lambda: (f["sbom"] or "").encode("utf-8"), f["sbom_name"], "application/json"),
            "notes": (lambda: f["tech_notes"].encode("utf-8"), f"{stem}.tech-notes.txt", "text/plain; charset=utf-8"),
            "suggestions": (lambda: f["suggestions"].encode("utf-8"), f"{stem}.suggestions.txt",
                            "text/plain; charset=utf-8"),
            "report": (lambda: _report_json(result), f"{stem}.report.json", "application/json"),
            "zip": (lambda: _zip_bytes(result), f"{stem}.sbom-fixer.zip", "application/zip"),
        }
        make, filename, ctype = table[kind]
        body = make()
        if not body:
            return self._error(HTTPStatus.NOT_FOUND, "This file was not produced.")
        self._send(HTTPStatus.OK, body, ctype, {"Content-Disposition": f'attachment; filename="{filename}"'})

    def _static(self, path: str) -> None:
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        target = (WEB / rel).resolve()
        if WEB not in target.parents or not target.is_file():
            return self._error(HTTPStatus.NOT_FOUND, "Not found.")
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        self._send(HTTPStatus.OK, target.read_bytes(), ctype)


def _free_port(host: str, wanted: int) -> int:
    for port in range(wanted, wanted + 60):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise SystemExit(f"No free port found between {wanted} and {wanted + 59}.")


def main() -> None:
    ap = argparse.ArgumentParser(description="SBOM Fixer Dashboard (offline)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    port = _free_port(args.host, args.port)
    server = ThreadingHTTPServer((args.host, port), Handler)
    url = f"http://{'127.0.0.1' if args.host in ('0.0.0.0', '') else args.host}:{port}/"
    print(f"SBOM Fixer Dashboard {analyzer.ENGINE_VERSION} is running at {url}")
    print("Keep this window open while you use it. Press Ctrl+C to stop.")
    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
        time.sleep(0.1)


if __name__ == "__main__":
    main()
