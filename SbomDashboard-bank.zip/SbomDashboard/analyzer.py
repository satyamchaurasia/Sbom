"""Run the sbom-fixer pipeline on an uploaded file and return everything the dashboard shows (one JSON-able dict).

This does the same work as `sbom-fixer fix` (convert -> validate -> repair -> Checkmarx layout) but returns data
instead of printing it. Nothing here touches the network.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import re
import tempfile
import time
from collections import Counter
from pathlib import Path
from typing import Any

from sbom_fixer import __version__ as ENGINE_VERSION
from sbom_fixer.audit.ntia import COMPONENT_FIELDS, DOC_FIELDS, NtiaReport
from sbom_fixer.cdxgen import to_cdxgen
from sbom_fixer.cdxgen_report import (
    _EXIT_TEXT,
    _example,
    _title,
    check_original,
    corrected_ntia_of,
    is_issue,
    ntia_summary,
    source_fix,
    suggestion_items,
    suggestions,
    tech_notes,
)
from sbom_fixer.detect import detect
from sbom_fixer.ecosystem import ECOSYSTEMS
from sbom_fixer.errors import DetectError, SbomFixerError
from sbom_fixer.jsonutil import iter_components
from sbom_fixer.pipeline import output_stem, run_fix
from sbom_fixer.profile import CanonicalPolicy, load_profile
from sbom_fixer.purlmap import classify
from sbom_fixer.serialize import write_json
from sbom_fixer.validate import group

MAX_CHANGES_SHOWN = 4000
MAX_COMPONENTS_SHOWN = 6000
MAX_GRAPH_NODES = 220
MAX_NODE_LINKS = 300  # names listed per node in the click panel
_NO_LICENCE = {"", "NOASSERTION", "NONE"}
_UUID_URN = re.compile(r"^urn:uuid:[0-9a-fA-F-]{36}$")


def ecosystems() -> list[str]:
    return list(ECOSYSTEMS)


# ---------------------------------------------------------------- small helpers


def _licences(c: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for lic in c.get("licenses") or []:
        if not isinstance(lic, dict):
            continue
        if lic.get("expression"):
            out.append(str(lic["expression"]))
        else:
            inner = lic.get("license") or {}
            value = inner.get("id") or inner.get("name")
            if value:
                out.append(str(value))
    return [x for x in out if x.upper() not in _NO_LICENCE]


def _ratio(ok: int, total: int) -> float:
    return 1.0 if total == 0 else ok / total


def _ntia_dict(report: NtiaReport | None) -> dict[str, Any] | None:
    if report is None:
        return None
    elements = []
    for name in COMPONENT_FIELDS:
        cov = report.components[name]
        elements.append({"name": name, "kind": "component", "covered": cov.covered, "total": cov.total,
                         "ok": cov.complete})
    for name in DOC_FIELDS:
        elements.append({"name": name, "kind": "document", "ok": bool(report.document.get(name))})
    return {"passed": report.passed, "summary": ntia_summary(report), "elements": elements,
            "passed_count": sum(1 for e in elements if e["ok"]), "element_count": len(elements)}


def _dependency_edges(doc: dict[str, Any]) -> tuple[int, int]:
    """(valid edges, all edges): an edge is valid when both ends are components of the file."""
    refs = {str(c.get("bom-ref")) for _, c in iter_components(doc, include_metadata=True) if c.get("bom-ref")}
    valid = total = 0
    for dep in doc.get("dependencies") or []:
        if not isinstance(dep, dict):
            continue
        for target in dep.get("dependsOn") or []:
            total += 1
            if str(dep.get("ref")) in refs and str(target) in refs:
                valid += 1
    return valid, total


def _readiness(doc: dict[str, Any], coverage: Any, schema_ok: bool) -> dict[str, dict[str, Any]]:
    """The checks a Checkmarx import cares about, each as a share between 0 and 1."""
    comps = [c for _, c in iter_components(doc)]
    n = len(comps)
    meta = doc.get("metadata") or {}
    root = meta.get("component") if isinstance(meta.get("component"), dict) else {}
    named = sum(1 for c in comps if c.get("name"))
    versioned = sum(1 for c in comps if c.get("version") and c.get("version") != "unknown")
    licensed = sum(1 for c in comps if _licences(c))
    scanned = coverage.scanned if coverage is not None else 0
    valid_edges, all_edges = _dependency_edges(doc)
    serial = bool(_UUID_URN.match(str(doc.get("serialNumber", ""))))

    def flag(ok: bool, label: str) -> dict[str, Any]:
        return {"label": label, "value": 1.0 if ok else 0.0, "detail": "yes" if ok else "no"}

    def share(ok: int, total: int, label: str) -> dict[str, Any]:
        return {"label": label, "value": _ratio(ok, total), "detail": f"{ok:,} of {total:,}"}

    return {
        "schema": flag(schema_ok, "File follows its schema"),
        "root": flag(bool(root.get("name")), "Application (root component) named"),
        "serial": flag(serial, "serialNumber is urn:uuid"),
        "timestamp": flag(bool(meta.get("timestamp")), "Timestamp present"),
        "tool": flag(bool(meta.get("tools")), "Generator tool recorded"),
        "names": share(named, n, "Components with a name"),
        "versions": share(versioned, n, "Components with a version"),
        "scanned": share(scanned, n, "Components Checkmarx can scan (valid purl)"),
        "licences": share(licensed, n, "Components with a licence"),
        "deps": ({"label": "Dependencies point to real components", "value": _ratio(valid_edges, all_edges),
                  "detail": f"{valid_edges:,} of {all_edges:,}"} if all_edges else
                 {"label": "Dependencies point to real components", "value": 0.0, "detail": "none written"}),
    }


def _readiness_rows(before: dict[str, dict[str, Any]], after: dict[str, dict[str, Any]]) -> dict[str, Any]:
    rows = [{"id": k, "label": v["label"], "before": v["value"], "after": after[k]["value"],
             "before_detail": v["detail"], "after_detail": after[k]["detail"]} for k, v in before.items()]
    score = lambda key: round(100 * sum(r[key] for r in rows) / len(rows)) if rows else 0  # noqa: E731
    return {"rows": rows, "before": score("before"), "after": score("after")}


def _coverage_dict(cov: Any) -> dict[str, Any] | None:
    if cov is None:
        return None
    return {"total": cov.total, "scanned": cov.scanned, "by_status": cov.by_status(),
            "by_type": [{"type": t, "count": n, "manager": pm, "status": st} for t, n, pm, st in cov.by_type()]}


def _graph(doc: dict[str, Any]) -> dict[str, Any]:
    comps = {str(c.get("bom-ref")): c for _, c in iter_components(doc, include_metadata=True) if c.get("bom-ref")}
    root_ref = str(((doc.get("metadata") or {}).get("component") or {}).get("bom-ref") or "")
    edges: list[tuple[str, str]] = []
    for dep in doc.get("dependencies") or []:
        if isinstance(dep, dict) and str(dep.get("ref")) in comps:
            edges += [(str(dep["ref"]), str(t)) for t in dep.get("dependsOn") or [] if str(t) in comps]
    degree: Counter[str] = Counter()
    for a, b in edges:
        degree[a] += 1
        degree[b] += 1
    ranked = sorted(comps, key=lambda r: (r != root_ref, -degree[r]))
    keep = ranked[:MAX_GRAPH_NODES]
    index = {r: i for i, r in enumerate(keep)}
    def label_of(r: str) -> str:
        c = comps[r]
        return f"{c.get('name', r)}@{c['version']}" if c.get("version") else str(c.get("name", r))

    deps_of: dict[str, list[str]] = {}
    used_by: dict[str, list[str]] = {}
    for a, b in edges:  # full lists (also links to components that are not drawn), shown when a node is clicked
        deps_of.setdefault(a, []).append(label_of(b))
        used_by.setdefault(b, []).append(label_of(a))
    nodes = []
    for r in keep:
        c = comps[r]
        purl = str(c.get("purl") or "")
        kind = purl.split(":", 1)[1].split("/", 1)[0] if purl.startswith("pkg:") and "/" in purl else "other"
        nodes.append({"id": r, "label": label_of(r), "type": kind, "degree": degree[r], "root": r == root_ref,
                      "deps": sorted(set(deps_of.get(r, [])))[:MAX_NODE_LINKS],
                      "used_by": sorted(set(used_by.get(r, [])))[:MAX_NODE_LINKS]})
    kept_edges = [[index[a], index[b]] for a, b in edges if a in index and b in index]
    return {"nodes": nodes, "edges": kept_edges, "total_nodes": len(comps), "total_edges": len(edges),
            "truncated": len(comps) > len(keep)}


def _component_changes(changes: list[Any]) -> dict[int, dict[str, int]]:
    out: dict[int, dict[str, int]] = {}
    for c in changes:
        m = re.match(r"^/components/(\d+)", c.path)
        if m:
            slot = out.setdefault(int(m.group(1)), {"fix": 0, "layout": 0})
            slot["fix" if is_issue(c) else "layout"] += 1
    return out


def _fail(file_name: str, size: int, sha: str, error: str, started: float) -> dict[str, Any]:
    return {"ok": False, "engine": ENGINE_VERSION, "error": error,
            "file": {"name": file_name, "size": size, "sha256": sha}, "seconds": round(time.time() - started, 2)}


# ---------------------------------------------------------------- the analysis


def analyze(raw: bytes, file_name: str, ecosystem: str | None = None, profile: str = "checkmarx") -> dict[str, Any]:
    started = time.time()
    sha = hashlib.sha256(raw).hexdigest()
    try:
        prof = load_profile(profile)
        canonical = dataclasses.replace(prof.canonical or CanonicalPolicy(), tool_per_ecosystem=True)
        if ecosystem:
            if ecosystem.lower() not in canonical.ecosystem_tools:
                raise SbomFixerError(f"Ecosystem must be one of {', '.join(sorted(canonical.ecosystem_tools))}.")
            canonical = dataclasses.replace(canonical, ecosystem=ecosystem.lower())
        prof = dataclasses.replace(prof, canonical=canonical)
        conv = to_cdxgen(raw)
        det, original_doc = detect(raw)
    except (DetectError, SbomFixerError) as exc:
        return _fail(file_name, len(raw), sha, str(exc), started)

    original = check_original(raw, file_name)
    stem = output_stem(Path(file_name))
    sbom_name = f"{stem}.corrected.cdx.json"
    with tempfile.TemporaryDirectory(prefix="sbom-dashboard-") as tmp:
        tmp_dir = Path(tmp)
        converted = tmp_dir / f"{stem}.converted.cdx.json"
        write_json(conv.doc, converted)
        out_dir = tmp_dir / "out"
        out_dir.mkdir()
        r = run_fix(converted, prof, out_dir, audit=False, sbom_name=sbom_name, reports=False)
        sbom_path = r.outputs.get("sbom")
        fixed_text = Path(sbom_path).read_text(encoding="utf-8") if sbom_path and Path(sbom_path).exists() else None

    tool_line = next((c.reason for c in r.log.changes if c.rule_id == "CXN-011" and c.path == "/metadata/tools"),
                     next((f.message for f in r.log.findings if f.rule_id == "CXN-011"), "tools unchanged"))
    fixed_doc = json.loads(fixed_text) if fixed_text else None
    issues = [c for c in r.log.changes if is_issue(c)]
    layout = [c for c in r.log.changes if not is_issue(c)]
    problems = suggestion_items(r, original)
    corrected_ntia = corrected_ntia_of(r)

    # readiness: the original as the generator wrote it (SPDX: after conversion) against the corrected file
    before_doc = original_doc if det.spec == "cyclonedx" and isinstance(original_doc, dict) else conv.doc
    before_cov = classify(before_doc, "cyclonedx", prof.purl)
    readiness = None
    if fixed_doc is not None:
        readiness = _readiness_rows(_readiness(before_doc, before_cov, not original.issues and not original.error),
                                    _readiness(fixed_doc, r.coverage, True))

    rules = []
    for kind, items_of_kind in (("fix", issues), ("layout", layout)):
        grouped: dict[str, list[Any]] = {}
        for c in items_of_kind:
            grouped.setdefault(c.rule_id, []).append(c)
        for rid, items in sorted(grouped.items(), key=lambda kv: (-len(kv[1]), kv[0])):
            rules.append({"id": rid, "title": _title(rid), "kind": kind, "count": len(items),
                          "example": _example(items[0]), "source_fix": source_fix(rid)})

    changes = [{"rule": c.rule_id, "title": _title(c.rule_id), "kind": "fix" if is_issue(c) else "layout",
                "path": c.path, "action": c.action, "severity": c.severity, "reason": c.reason,
                "before": _clip(c.before), "after": _clip(c.after)} for c in r.log.changes[:MAX_CHANGES_SHOWN]]

    per_component = _component_changes(r.log.changes)
    components = []
    if fixed_doc is not None and r.coverage is not None:
        cov_by_path = {row.path: row for row in r.coverage.rows}
        for i, c in enumerate(fixed_doc.get("components") or []):
            if i >= MAX_COMPONENTS_SHOWN:
                break
            row = cov_by_path.get(f"/components/{i}")
            counts = per_component.get(i, {"fix": 0, "layout": 0})
            components.append({"name": c.get("name", ""), "version": c.get("version", ""), "purl": c.get("purl", ""),
                               "type": c.get("type", ""), "licences": _licences(c) or [],
                               "status": row.status if row else "", "manager": row.checkmarx_pm if row else "",
                               "reason": row.reason if row else "", "original_purl": row.original_purl if row else "",
                               "fixes": counts["fix"], "layout": counts["layout"]})

    licence_count: Counter[str] = Counter()
    unknown = 0
    for c in (fixed_doc or {}).get("components") or []:
        names = _licences(c)
        if names:
            licence_count.update(set(names))
        else:
            unknown += 1

    final_ok = r.ok and fixed_text is not None
    deps = (fixed_doc or {}).get("dependencies")
    notes_text = tech_notes(r, conv, original, sbom_name, tool_line)
    advice_text = suggestions(r, original)
    result: dict[str, Any] = {
        "ok": final_ok,
        "engine": ENGINE_VERSION,
        "seconds": round(time.time() - started, 2),
        "error": None if final_ok else (r.error or "Schema errors remain; the corrected SBOM was not written."),
        "file": {"name": file_name, "size": len(raw), "sha256": sha},
        "input": {"spec": conv.source_spec, "version": conv.source_version, "generator": original.generator,
                  "components": original.components, "encoding": det.encoding},
        "output": {"name": sbom_name, "version": r.final_version, "components": len((fixed_doc or {}).get("components") or []),
                   "dependencies": len(deps) if isinstance(deps, list) else 0},
        "exit": {"code": r.exit_code, "text": _EXIT_TEXT.get(r.exit_code, "see README")},
        "tool": tool_line,
        "counts": {
            "problems": len(problems),
            "changes": len(r.log.changes),
            "fixes": len(issues),
            "layout": len(layout),
            "schema_errors_original": len(original.issues),
            "schema_errors_converted": len(r.original_issues),
            "original_not_validated": original.error,
            "severity": {s: r.log.count(s) for s in ("INFO", "WARN", "DATA_LOSS")},
            "problems_by_kind": dict(Counter(p["kind"] for p in problems)),
        },
        "ntia": {"original": _ntia_dict(original.ntia), "corrected": _ntia_dict(corrected_ntia)},
        "readiness": readiness,
        "checkmarx": {"before": _coverage_dict(before_cov), "after": _coverage_dict(r.coverage)},
        "problems": problems,
        "schema_errors": [{"keyword": kw, "path": pth, "count": n, "message": msg}
                          for kw, pth, n, msg in group(original.issues)],
        "rules": rules,
        "changes": changes,
        "changes_total": len(r.log.changes),
        "findings": [{"rule": f.rule_id, "path": f.path, "message": f.message, "severity": f.severity}
                     for f in r.log.findings],
        "conversion_notes": conv.notes,
        "components": components,
        "components_total": len((fixed_doc or {}).get("components") or []),
        "licences": {"top": licence_count.most_common(12), "unknown": unknown},
        "graph": _graph(fixed_doc) if fixed_doc is not None else None,
        "files": {"sbom": fixed_text, "sbom_name": sbom_name, "tech_notes": notes_text, "suggestions": advice_text,
                  "stem": stem},
    }
    return result


def _clip(value: Any, limit: int = 160) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
    text = text.replace("\r", " ").replace("\n", " ")
    return text if len(text) <= limit else text[: limit - 3] + "..."
