#!/usr/bin/env sh
# SBOM Fixer Dashboard - run:  sh start.sh   (works without internet)
cd "$(dirname "$0")" || exit 1

PY=""
for candidate in python3 python; do
  if command -v "$candidate" >/dev/null 2>&1; then PY="$candidate"; break; fi
done
if [ -z "$PY" ]; then
  echo "Python 3.11 or newer is needed and was not found. Install it once, then run this again."
  exit 1
fi
if ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
  echo "This computer has an old Python. Python 3.11 or newer is needed."
  exit 1
fi
exec "$PY" app.py "$@"
