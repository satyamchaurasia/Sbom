@echo off
rem SBOM Fixer Dashboard - double-click to start. Works without internet.
setlocal
cd /d "%~dp0"
title SBOM Fixer Dashboard

set "PY="
where py >nul 2>nul && py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY ( where python3 >nul 2>nul && set "PY=python3" )
if not defined PY (
  echo.
  echo  Python 3.11 or newer is needed and was not found on this computer.
  echo  Install it once from python.org ^(tick "Add python.exe to PATH"^), then double-click start.bat again.
  echo.
  pause
  exit /b 1
)

%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 (
  echo.
  echo  This computer has an old Python. Python 3.11 or newer is needed.
  echo.
  pause
  exit /b 1
)

%PY% app.py %*
if errorlevel 1 (
  echo.
  echo  The dashboard stopped with an error. Read the message above.
  pause
)
endlocal
