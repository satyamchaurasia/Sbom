"""Checkmarx canonical form (CXN-*): reduce a repaired CycloneDX SBOM to the shape Checkmarx One SCA ingests reliably.

A schema-valid SBOM is not always ingested by Checkmarx: extra fields (hashes with SHA3 algorithms, evidence,
properties, externalReferences, services, vulnerabilities, the 1.5+ tools object, purl qualifiers, ...) make some
uploads fail or come back with 0 packages. The form below is the one that imports reliably (the cyclonedx-dotnet
layout): every component is {bom-ref, type, name, version, purl, licenses}, metadata is {timestamp, tools, component},
dependencies only point at components that exist.

These rules run once, after the repair and the Checkmarx purl rules (CXP-*), at the final version and only when the
profile has a `canonical:` section. Execution order is registration order. The spec version is never changed.
"""

from __future__ import annotations

import re
import uuid
from datetime import UTC, datetime
from typing import Any
from urllib.parse import unquote, urlsplit

from packageurl import PackageURL

from ..binpath import looks_like_file, purl_from_component_paths
from ..changes import INFO, WARN
from ..ecosystem import detect_ecosystem
from ..purlmap import URL_RE, try_purl
from .base import Ctx, Rule, register
from .sanitize import _ECOSYSTEM_HINTS, _HINT_PROPS, _version_at_least
from .sanitize_purl import _build

CANONICAL = "canonical"

TOP_LEVEL = ("bomFormat", "specVersion", "serialNumber", "version", "metadata", "components", "dependencies")
_MISSING = object()


class CanonicalRule(Rule):
    case, kind, specs = "C", CANONICAL, ("cyclonedx",)

    def apply(self, doc: Any, ctx: Ctx) -> None:
        if ctx.profile.canonical is None or not isinstance(doc, dict):
            return
        self.run(doc, ctx)

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        raise NotImplementedError


def is_reduction(change: Any) -> bool:
    """True for a canonical change that only trims the layout for Checkmarx (dropped sections and fields, reshaped
    metadata, flattened nesting, shortened licences): not an issue of the original SBOM."""
    rid, action, reason = change.rule_id, change.action, change.reason or ""
    if rid == "CXN-001" or (rid == "CXN-011" and not change.path.startswith("/metadata/component")):
        return True
    if rid in ("CXN-010", "CXN-040") and action == "removed":
        return True
    if rid == "CXN-030" and action == "replaced":
        return True
    if rid in ("CXN-020", "CXN-040") and change.path.endswith("/purl") and isinstance(change.before, str):
        # only qualifiers (?type=jar) or the subpath dropped: a valid purl, shortened for this copy
        return re.split(r"[?#]", change.before, maxsplit=1)[0] == change.after
    return rid == "CXN-050" and (reason.startswith("dependency fields") or action == "added")


def _components(doc: dict[str, Any]) -> list[dict[str, Any]]:
    comps = doc.get("components")
    return [c for c in comps if isinstance(c, dict)] if isinstance(comps, list) else []


def _str(value: Any) -> str | None:
    if value is None or isinstance(value, (dict, list, bool)):
        return None
    text = str(value).strip()
    return text or None


@register
class FlattenAll(CanonicalRule):
    id = "CXN-001"
    title = "All components at the top level"
    description = ("Components nested inside other components (or inside metadata.component) were moved to the "
                   "top-level components list; Checkmarx reads only the top level.")

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        flat: list[Any] = []

        def rec(comps: list[Any], base: str) -> None:
            for i, c in enumerate(comps):
                if not isinstance(c, dict):
                    continue
                flat.append(c)
                children = c.pop("components", None)
                if isinstance(children, list) and children:
                    ctx.log.add(self.id, f"{base}/{i}/components", "moved", f"{len(children)} components",
                                "/components", INFO, "Nested components moved to the top level")
                    rec(children, f"{base}/{i}/components")

        meta = doc.get("metadata")
        root = meta.get("component") if isinstance(meta, dict) else None
        if isinstance(root, dict) and isinstance(root.get("components"), list):
            children = root.pop("components")
            if children:
                ctx.log.add(self.id, "/metadata/component/components", "moved", f"{len(children)} components",
                            "/components", INFO, "Components nested in metadata.component moved to the top level")
            rec(children, "/metadata/component/components")
        if isinstance(doc.get("components"), list):
            rec(list(doc["components"]), "/components")
        if flat or "components" in doc:
            doc["components"] = flat


def _ecosystem(c: dict[str, Any]) -> str | None:
    """Package ecosystem when the component data says so; None when it is a guess."""
    for prop in c.get("properties") or []:
        if isinstance(prop, dict) and prop.get("name") in _HINT_PROPS:
            eco = _ECOSYSTEM_HINTS.get(str(prop.get("value", "")).lower())
            if eco:
                return eco
    name = c.get("name")
    if isinstance(name, str) and name.startswith("@") and "/" in name:
        return "npm"
    return None


# ecosystem (ecosystem.py) -> purl type for components that have no purl
ECOSYSTEM_PURL_TYPE = {
    "dotnet": "nuget", "java": "maven", "node": "npm", "python": "pypi", "go": "golang", "ruby": "gem",
    "php": "composer", "rust": "cargo", "erlang": "hex", "dart": "pub", "swift": "swift", "cpp": "conan",
    "perl": "cpan",
}
_NEEDS_NAMESPACE = {"maven", "composer", "swift"}


def document_ecosystem(doc: dict[str, Any]) -> str | None:
    """The one ecosystem the whole SBOM belongs to, or None when it is mixed or unknown. Used only to build purls for
    components without one: every component purl that exists is of that ecosystem (or there are none and the root
    component or the generator names it)."""
    res = detect_ecosystem(doc)
    if res.ecosystem is None or len(res.counts) > 1:
        return None
    return res.ecosystem


def _same_name(a: str, b: str) -> bool:
    """Package names that differ only in case, '-', '_' or '.' (registries normalise them differently)."""
    return re.sub(r"[-_.]", "", a).lower() == re.sub(r"[-_.]", "", b).lower()


def _from_references(c: dict[str, Any], version: str | None) -> PackageURL | None:
    """purl from a registry URL in the component's externalReferences (distribution, website, vcs, ...)."""
    from ..purlmap import purl_from_url

    for ref in c.get("externalReferences") or []:
        url = ref.get("url") if isinstance(ref, dict) else None
        if isinstance(url, str):
            p = purl_from_url(url, version, allow_github=False)
            if p is not None:
                return p
    return None


_URL_IN_PURL = re.compile(r"https?(:|%3a)", re.IGNORECASE)


def has_url(purl: str) -> bool:
    """True when a purl carries a web URL anywhere (type, namespace, name, qualifiers), also percent-encoded."""
    return bool(_URL_IN_PURL.search(purl))


def _dashes(name: str) -> str:
    """Package name for a purl: a URL becomes its last path segment (or host), whitespace becomes dashes."""
    text = name.strip()
    if URL_RE.match(text):
        parts = urlsplit(text)
        segs = [x for x in parts.path.split("/") if x]
        text = unquote(segs[-1]) if segs else (parts.hostname or "package")
    return re.sub(r"\s+", "-", text) or "package"


def canonical_purl(c: dict[str, Any], keep_qualifiers: bool, fallback: str,
                   doc_ecosystem: str | None = None) -> tuple[str | None, str]:
    """(purl, how) for a component. how: kept | normalized | from-bom-ref | built | from-url | from-ecosystem |
    generic | none.

    The result never contains a web URL (http/https, also percent-encoded): Checkmarx cannot match such a purl.
    """
    purl, how = _canonical_purl(c, keep_qualifiers, fallback, doc_ecosystem)
    if purl is not None and has_url(purl):
        p = try_purl(purl)
        if p is not None and not has_url(PackageURL(type=p.type, namespace=p.namespace, name=p.name,
                                                    version=p.version).to_string()):
            return PackageURL(type=p.type, namespace=p.namespace, name=p.name, version=p.version).to_string(), "normalized"
        name = _str(c.get("name")) or (p.name if p else "package")
        if fallback != "generic":
            return None, "none"
        return PackageURL(type="generic", name=_dashes(name), version=_str(c.get("version"))).to_string(), "generic"
    return purl, how


def _canonical_purl(c: dict[str, Any], keep_qualifiers: bool, fallback: str,
                    doc_ecosystem: str | None = None) -> tuple[str | None, str]:
    version = _str(c.get("version"))
    original = c.get("purl")
    source, p = "purl", try_purl(original) if isinstance(original, str) else None
    if p is None:
        ref = c.get("bom-ref")
        if isinstance(ref, str) and ref.lower().startswith("pkg:"):
            source, p = "bom-ref", try_purl(ref)
    if p is not None and has_url(p.to_string().split("?", 1)[0]):
        p = None  # a URL inside namespace or name: not a usable purl, rebuilt below
    if p is not None and p.type.lower() == "generic":
        cached = purl_from_component_paths(c)  # a generic DLL/JAR that sits in a NuGet or Maven cache
        if cached is not None:
            return cached.to_string(), "from-path"
    if p is not None:
        new = PackageURL(type=p.type.lower(), namespace=p.namespace, name=p.name, version=p.version or version,
                         qualifiers=p.qualifiers if keep_qualifiers else None,
                         subpath=p.subpath if keep_qualifiers else None).to_string()
        if source == "bom-ref":
            return new, "from-bom-ref"
        return new, "kept" if new == original else "normalized"
    name = _str(c.get("name"))
    if not name:
        return None, "none"
    cached = purl_from_component_paths(c)
    if cached is not None:
        return cached.to_string(), "from-path"
    eco = _ecosystem(c)
    if eco:
        try:
            built = _build(eco, _dashes(name), version, _str(c.get("group")))
        except ValueError:
            built = None
        if built is not None:
            return built.to_string(), "built"
    found = _from_references(c, version)
    if found is not None and _same_name(found.name, name):
        return PackageURL(type=found.type, namespace=found.namespace, name=found.name,
                          version=version or found.version).to_string(), "from-url"
    ptype = ECOSYSTEM_PURL_TYPE.get(doc_ecosystem or "")
    group = _str(c.get("group"))
    # a file name (Newtonsoft.Json.dll, version 13.0.0.0 = assembly version) is not a package name: never guessed
    if ptype and version and (group or ptype not in _NEEDS_NAMESPACE) and not looks_like_file(name):
        try:
            built = _build(ptype, _dashes(name), version, group)
        except ValueError:
            built = None
        if built is not None:
            return built.to_string(), "from-ecosystem"
    if fallback != "generic":
        return None, "none"
    return PackageURL(type="generic", namespace=_str(c.get("group")), name=_dashes(name), version=version).to_string(), "generic"


@register
class PurlCanonical(CanonicalRule):
    id = "CXN-020"
    title = "purl in the form Checkmarx matches"
    description = ("Every component got a purl of the form pkg:type/[namespace/]name@version: the type in lower case, "
                   "qualifiers and subpath removed (Checkmarx does not use them), the version filled from the component. "
                   "A missing (or generic) purl of a DLL/JAR in a NuGet or Maven cache path became that package's purl. "
                   "A missing purl was built from the bom-ref, the component's registry URL, or the SBOM's one "
                   "ecosystem (Erlang -> pkg:hex, .NET -> pkg:nuget, ...; not when the SBOM mixes ecosystems, and never "
                   "for a file name such as Foo.dll), otherwise as "
                   "pkg:generic/<name>@<version> (Checkmarx skips generic components but no purl is ever null). A purl never "
                   "holds a web URL (http/https): URLs are converted to the registry purl or dropped.")
    source_fix = "Let the generator write a plain purl (pkg:type/namespace/name@version) for every component."

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        policy = ctx.profile.canonical
        assert policy is not None
        doc_eco = policy.ecosystem or document_ecosystem(doc)
        for i, c in enumerate(_components(doc)):
            old = c.get("purl")
            new, how = canonical_purl(c, policy.keep_purl_qualifiers, policy.purl_fallback, doc_eco)
            path = f"/components/{i}/purl"
            if new is None:
                if old is not None:
                    c.pop("purl", None)
                ctx.log.note(self.id, f"/components/{i}", f"Component '{c.get('name')}' has no name to build a purl from")
                continue
            if new == old:
                continue
            c["purl"] = new
            reason = {
                "normalized": "purl reduced to type/namespace/name@version",
                "from-bom-ref": "purl taken from the bom-ref",
                "built": "purl built from the ecosystem named by the generator",
                "from-url": "purl taken from the component's registry URL (externalReferences)",
                "from-path": "purl taken from the package-cache path of the file (NuGet / Maven cache)",
                "from-ecosystem": f"no purl; built for the SBOM's ecosystem ({doc_eco}: pkg:{ECOSYSTEM_PURL_TYPE.get(doc_eco or '')})",
                "generic": "no ecosystem known; generic purl so the component has one (Checkmarx will not scan it)",
            }.get(how, how)
            ctx.log.add(self.id, path, "replaced" if old is not None else "added", old, new,
                        WARN if how == "generic" else INFO, reason)
            package = try_purl(new) if how == "from-path" else None
            if package is not None and package.version and c.get("version") != package.version:
                # the file version (assembly / manifest version) is not the package version Checkmarx looks up
                ctx.log.add(self.id, f"/components/{i}/version", "replaced", c.get("version"), package.version, INFO,
                            "version set to the package version from the cache path (the file version differs)")
                c["version"] = package.version


def canonical_licenses(value: Any) -> list[dict[str, Any]]:
    """Licenses reduced to {license: {id}} / {license: {name}} entries, or one {expression}."""
    if not isinstance(value, list):
        return []
    licenses: list[dict[str, Any]] = []
    expressions: list[str] = []
    for entry in value:
        if not isinstance(entry, dict):
            continue
        expr = _str(entry.get("expression"))
        lic = entry.get("license")
        if expr:
            expressions.append(expr)
        elif isinstance(lic, dict):
            if _str(lic.get("id")):
                item = {"license": {"id": _str(lic["id"])}}
            elif _str(lic.get("name")):
                item = {"license": {"name": _str(lic["name"])}}
            else:
                continue
            if item not in licenses:
                licenses.append(item)
    if licenses:
        return licenses
    return [{"expression": expressions[0]}] if expressions else []


@register
class LicensesCanonical(CanonicalRule):
    id = "CXN-030"
    title = "Every component has a licence"
    description = ("Licences were reduced to the SPDX id or name (or one expression); licence text, URLs and other "
                   "details were dropped. A component without a licence got NOASSERTION, because Checkmarx rejects "
                   "empty licence arrays.")
    source_fix = ("Make the generator record the licence of every package (SPDX id such as MIT or Apache-2.0); "
                  "packages without licence metadata need it added in the package manifest.")

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        policy = ctx.profile.canonical
        assert policy is not None
        if "licenses" not in policy.component_fields:
            return
        # NOASSERTION is not in the SPDX licence id list of the CycloneDX schema, so it goes in "name"
        default = [{"license": {"name": policy.default_license}}]
        for i, c in enumerate(_components(doc)):
            old = c.get("licenses", _MISSING)
            new = canonical_licenses(old)
            if not new:
                new = [dict(x, license=dict(x["license"])) for x in default]
                reason = f"No licence; {policy.default_license} added"
            else:
                reason = "Licences reduced to id / name / expression"
            if old is _MISSING or new != old:
                c["licenses"] = new
                ctx.log.add(self.id, f"/components/{i}/licenses", "added" if old is _MISSING else "replaced",
                            None if old is _MISSING else old, new, INFO, reason)


@register
class ComponentsCanonical(CanonicalRule):
    id = "CXN-040"
    title = "Components reduced to the fields Checkmarx reads"
    description = ("Each component was reduced to bom-ref, type, name, version, purl and licenses (profile key "
                   "canonical.component_fields). Hashes, evidence, properties, externalReferences, descriptions and "
                   "the other fields Checkmarx does not read were dropped; the original SBOM still has them. A missing "
                   "bom-ref (or one holding a web URL, renamed in dependencies too) was set to the purl (or the name), "
                   "a missing type to library.")
    source_fix = "Give every component a bom-ref (cdxgen uses the purl) and a type; never a web URL as bom-ref."

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        policy = ctx.profile.canonical
        assert policy is not None
        comps = _components(doc)
        meta = doc.get("metadata")
        root = meta.get("component") if isinstance(meta, dict) else None
        renames: dict[str, str] = {}  # bom-refs that held a web URL -> their replacement
        if isinstance(root, dict):
            self._root_without_urls(root, ctx, renames)
        used: set[str] = {root["bom-ref"]} if isinstance(root, dict) and isinstance(root.get("bom-ref"), str) else set()
        needs_version = not _version_at_least(ctx.version, "1.4")
        out: list[dict[str, Any]] = []
        for i, c in enumerate(comps):
            path = f"/components/{i}"
            purl = c.get("purl") if isinstance(c.get("purl"), str) else None
            p = try_purl(purl) if purl else None
            name = _str(c.get("name")) or (p.name if p else None) or _str(c.get("bom-ref")) or "unknown"
            version = _str(c.get("version")) or (p.version if p else None)
            if version is None and needs_version:
                version = "unknown"  # version is required before CycloneDX 1.4
            ref = _str(c.get("bom-ref"))
            url_ref = ref if ref is not None and has_url(ref) else None
            if url_ref:
                ref = None
            if ref is None or ref in used:
                base = purl or (f"{name}@{version}" if version else name)
                ref, n = base, 1
                while ref in used:
                    n += 1
                    ref = f"{base}#{n}"
                ctx.log.add(self.id, f"{path}/bom-ref", "added" if c.get("bom-ref") is None else "replaced",
                            c.get("bom-ref"), ref, INFO,
                            "bom-ref held a web URL; replaced by the purl" if url_ref else "bom-ref missing or not unique")
            if url_ref:
                renames[url_ref] = ref
            used.add(ref)
            values: dict[str, Any] = {
                "bom-ref": ref,
                "type": _str(c.get("type")) or "library",
                "name": name,
                "version": version,
                "purl": purl,
                "licenses": c.get("licenses"),
            }
            new: dict[str, Any] = {}
            for key in policy.component_fields:
                value = values[key] if key in values else c.get(key)
                if value is not None:
                    new[key] = value
            dropped = sorted(k for k in c if k not in new)
            if dropped:
                ctx.log.add(self.id, path, "removed", {k: c[k] for k in dropped}, None, WARN,
                            f"Fields not read by Checkmarx dropped: {', '.join(dropped)}")
            out.append(new)
        if "components" in doc or out:
            doc["components"] = out
        if renames:
            for d in doc.get("dependencies") or []:
                if not isinstance(d, dict):
                    continue
                if d.get("ref") in renames:
                    d["ref"] = renames[d["ref"]]
                if isinstance(d.get("dependsOn"), list):
                    d["dependsOn"] = [renames.get(t, t) if isinstance(t, str) else t for t in d["dependsOn"]]

    def _root_without_urls(self, root: dict[str, Any], ctx: Ctx, renames: dict[str, str]) -> None:
        """metadata.component keeps its fields; its purl gets the same form as the components' purls (no qualifiers, no
        web URL) and a bom-ref holding a web URL is replaced."""
        policy = ctx.profile.canonical
        assert policy is not None
        old = root.get("purl")
        if isinstance(old, str) and has_url(old):
            new, _ = canonical_purl(root, policy.keep_purl_qualifiers, policy.purl_fallback)
            if new is None:
                root.pop("purl")
            else:
                root["purl"] = new
            ctx.log.add(self.id, "/metadata/component/purl", "replaced" if new else "removed", old, new, INFO,
                        "purl held a web URL")
        elif isinstance(old, str):
            new, how = canonical_purl(root, policy.keep_purl_qualifiers, policy.purl_fallback)
            if new is not None and new != old and how == "normalized":
                root["purl"] = new
                ctx.log.add(self.id, "/metadata/component/purl", "replaced", old, new, INFO,
                            "purl reduced to type/namespace/name@version")
        ref = root.get("bom-ref")
        if isinstance(ref, str) and has_url(ref):
            new_ref = root.get("purl") or _dashes(str(root.get("name") or "application"))
            root["bom-ref"] = renames[ref] = new_ref
            ctx.log.add(self.id, "/metadata/component/bom-ref", "replaced", ref, new_ref, INFO,
                        "bom-ref held a web URL; replaced by the purl")


def canonical_tools(doc: dict[str, Any], policy: Any) -> tuple[list[dict[str, str]], str]:
    """(metadata.tools, reason): the profile's tool list, or with tool_per_ecosystem the tool for the ecosystem."""
    tools = [dict(t) for t in policy.tools]
    if not policy.tool_per_ecosystem:
        return tools, "Tools set to the profile's canonical tool list"
    found = detect_ecosystem(doc, force=policy.ecosystem)
    name = policy.ecosystem_tools.get(found.ecosystem or "")
    if name is None:
        return tools, f"{found.describe()}; the profile's default tool ({tools[0].get('name')}) kept"
    base = tools[0]
    entry = {k: base[k] for k in ("vendor",) if base.get(k)} | {"name": name} | {k: base[k] for k in ("version",) if base.get(k)}
    return [entry], f"Tool {name} for the {found.describe()}"


@register
class MetadataCanonical(CanonicalRule):
    id = "CXN-011"
    title = "metadata is timestamp, tools and component"
    description = ("metadata was reduced to timestamp (kept; added when missing), tools (the tool list of the "
                   "profile, by default cyclonedx-dotnet in the 1.4 array form, which Checkmarx reads in every version; "
                   "with tool_per_ecosystem the name follows the detected ecosystem: cyclonedx-java, cyclonedx-node, ...) "
                   "and the root component (kept as it was; when missing it is added with the fields the schema "
                   "requires left blank: type application, name \"\", and version \"\" for CycloneDX 1.2/1.3). Other "
                   "metadata (authors, lifecycles, properties, ...) was dropped.")
    source_fix = "Let the generator write metadata.component: the application the SBOM describes, with name and version."

    def _root(self, root: Any, ctx: Ctx) -> dict[str, Any]:
        """metadata.component is always written; missing required fields are left blank, never invented."""
        required = {"type": "application", "name": ""}
        if ctx.version in ("1.2", "1.3"):
            required["version"] = ""
        if not isinstance(root, dict):
            ctx.log.add(self.id, "/metadata/component", "added", root, required, WARN,
                        "No metadata.component; added with the required fields blank")
            return dict(required)
        for key, blank in required.items():
            if not isinstance(root.get(key), str) or (key == "type" and not root[key]):
                ctx.log.add(self.id, f"/metadata/component/{key}", "added" if key not in root else "replaced",
                            root.get(key), blank, WARN, f"metadata.component has no {key}; set to {blank!r}")
                root[key] = blank
        return root

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        policy = ctx.profile.canonical
        assert policy is not None
        old = doc.get("metadata")
        old = old if isinstance(old, dict) else {}
        new: dict[str, Any] = {}
        ts = old.get("timestamp")
        if isinstance(ts, str) and ts:
            new["timestamp"] = ts
        else:
            new["timestamp"] = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
            ctx.log.add(self.id, "/metadata/timestamp", "added", None, new["timestamp"], INFO, "No timestamp; set to now")
        tools, why = canonical_tools(doc, policy)
        new["tools"] = tools
        if old.get("tools") != tools:
            ctx.log.add(self.id, "/metadata/tools", "replaced" if "tools" in old else "added", old.get("tools"), tools,
                        INFO, why)
        elif policy.tool_per_ecosystem:
            ctx.log.note(self.id, "/metadata/tools", why, INFO)
        new["component"] = self._root(old.get("component"), ctx)
        dropped = sorted(k for k in old if k not in ("timestamp", "tools", "component"))
        if dropped:
            ctx.log.add(self.id, "/metadata", "removed", {k: old[k] for k in dropped}, None, WARN,
                        f"metadata fields not read by Checkmarx dropped: {', '.join(dropped)}")
        doc["metadata"] = new


@register
class DependenciesCanonical(CanonicalRule):
    id = "CXN-050"
    title = "Dependencies point only at existing components"
    description = ("dependencies entries were reduced to ref and dependsOn. An entry whose ref is not a component "
                   "(or the root component) was removed; dependsOn values that are not a component bom-ref, "
                   "self-references and duplicates were removed; entries with the same ref were merged.")
    source_fix = ("List dependencies only between components that are in the SBOM, without self-dependencies and "
                  "with one entry per ref.")

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        deps = doc.get("dependencies") or []
        refs = [c["bom-ref"] for c in _components(doc) if isinstance(c.get("bom-ref"), str)]
        valid = set(refs)
        meta = doc.get("metadata")
        root = meta.get("component") if isinstance(meta, dict) else None
        if isinstance(root, dict) and isinstance(root.get("bom-ref"), str):
            valid.add(root["bom-ref"])
        merged: dict[str, list[str]] = {}
        for i, d in enumerate(deps if isinstance(deps, list) else []):
            path = f"/dependencies/{i}"
            ref = d.get("ref") if isinstance(d, dict) else None
            if not isinstance(ref, str) or ref not in valid:
                ctx.log.add(self.id, path, "removed", d, None, WARN, "ref is not a component in this SBOM")
                continue
            targets = merged.setdefault(ref, [])
            for j, t in enumerate(d.get("dependsOn") or []):
                if t == ref:
                    ctx.log.add(self.id, f"{path}/dependsOn/{j}", "removed", t, None, INFO, "self-dependency (cycle)")
                elif not isinstance(t, str) or t not in valid:
                    ctx.log.add(self.id, f"{path}/dependsOn/{j}", "removed", t, None, WARN,
                                "dependsOn points at a component that does not exist")
                elif t not in targets:
                    targets.append(t)
            extra = sorted(k for k in d if k not in ("ref", "dependsOn"))
            if extra:
                ctx.log.add(self.id, path, "removed", {k: d[k] for k in extra}, None, INFO,
                            f"dependency fields not read by Checkmarx dropped: {', '.join(extra)}")
        for ref in ([root["bom-ref"]] if isinstance(root, dict) and isinstance(root.get("bom-ref"), str) else []) + refs:
            if ref not in merged:  # cdxgen layout: every component has an entry (dependsOn unknown = [])
                merged[ref] = []
                ctx.log.add(self.id, "/dependencies/-", "added", None, {"ref": ref, "dependsOn": []}, INFO,
                            "dependencies entry added for a component without one (dependsOn unknown)")
        if merged or "dependencies" in doc:
            doc["dependencies"] = [{"ref": r, "dependsOn": t} for r, t in merged.items()]


@register
class TopLevelCanonical(CanonicalRule):
    id = "CXN-010"
    title = "Top level is bomFormat, specVersion, serialNumber, version, metadata, components, dependencies"
    description = ("Top-level sections Checkmarx does not read (services, compositions, vulnerabilities, "
                   "annotations, externalReferences, properties, formulation, declarations, definitions, signature, "
                   "$schema) were dropped. bomFormat and specVersion are kept as they were; serialNumber and version "
                   "were added when missing; components is always present (an empty list when there are none).")
    source_fix = "Let the generator write serialNumber (urn:uuid:...), version 1 and a components list."

    def run(self, doc: dict[str, Any], ctx: Ctx) -> None:
        if not (isinstance(doc.get("serialNumber"), str) and doc["serialNumber"]):
            serial = f"urn:uuid:{uuid.uuid5(uuid.NAMESPACE_URL, 'sbom-fixer:' + ctx.source_sha256)}"
            doc["serialNumber"] = serial
            ctx.log.add(self.id, "/serialNumber", "added", None, serial, INFO, "No serialNumber; derived from the input hash")
        if not isinstance(doc.get("version"), int) or isinstance(doc.get("version"), bool) or doc["version"] < 1:
            ctx.log.add(self.id, "/version", "replaced" if "version" in doc else "added", doc.get("version"), 1, INFO,
                        "BOM version set to 1")
            doc["version"] = 1
        if not isinstance(doc.get("components"), list):
            ctx.log.add(self.id, "/components", "replaced" if "components" in doc else "added", doc.get("components"), [],
                        INFO, "No components list; written as an empty list (the layout always has components)")
            doc["components"] = []
        dropped = [k for k in doc if k not in TOP_LEVEL]
        for k in dropped:
            ctx.log.add(self.id, f"/{k}", "removed", doc[k], None, WARN, "top-level section not read by Checkmarx")
        ordered = {k: doc[k] for k in TOP_LEVEL if k in doc}
        doc.clear()
        doc.update(ordered)
